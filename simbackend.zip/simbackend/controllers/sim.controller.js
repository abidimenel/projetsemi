import Sim from '../models/sim.model.js';

// Utility function for error handling
const handleError = (res, statusCode, message, error) => {
  console.error(message, error);
  res.status(statusCode).json({ message, error: error.message });
};

// Create a SIM
export const createSim = async (req, res) => {
  try {
    const { serialNumber } = req.body;
    if (!serialNumber) {
      return res.status(400).json({ message: 'Serial number is required' });
    }

    const sim = new Sim({ serialNumber });
    await sim.save();

    res.status(201).json({ message: 'SIM created successfully', sim });
  } catch (error) {
    handleError(res, 500, 'Error creating SIM', error);
  }
};

// Assign a SIM to an employee
export const assignSimToEmployee = async (req, res) => {
  try {
    const { serialNumber, nom, cin, poste, service, forfait, forfaitInternet } = req.body;

    console.log('Received data:', req.body); // Debugging

    if (!serialNumber || !nom || !cin || !poste || !service || !forfait || !forfaitInternet) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    const sim = await Sim.findOne({ serialNumber });
    if (!sim) {
      return res.status(404).json({ message: 'SIM not found' });
    }

    // Reset if already assigned
    sim.employee = { nom, cin, poste, service };
    sim.forfait = forfait;
    sim.forfaitInternet = forfaitInternet;
    sim.assignedAt = Date.now();

    await sim.save();

    res.status(200).json({ message: 'SIM assigned successfully', sim });
  } catch (error) {
    handleError(res, 500, 'Error assigning SIM to employee', error);
  }
};

// Assign a phone number to a SIM
export const assignPhoneNumberToSim = async (req, res) => {
  try {
    const { serialNumber, phoneNumber } = req.body;

    if (!serialNumber || !phoneNumber) {
      return res.status(400).json({ message: 'Serial number and phone number are required' });
    }

    const sim = await Sim.findOne({ serialNumber });
    if (!sim) {
      return res.status(404).json({ message: 'SIM not found' });
    }

    sim.phoneNumber = phoneNumber;
    await sim.save();

    res.status(200).json({ message: 'Phone number assigned successfully', sim });
  } catch (error) {
    handleError(res, 500, 'Error assigning phone number', error);
  }
};

// Get all SIMs
export const getAllSims = async (req, res) => {
  try {
    const sims = await Sim.find({});
    res.status(200).json({ message: 'SIM cards fetched successfully', sims });
  } catch (error) {
    handleError(res, 500, 'Error fetching SIMs', error);
  }
};

/// Delete SIM controller function
export const deleteSim = (req, res) => {
  const { serialNumber } = req.query; // Get the serial number from the query parameter

  if (!serialNumber) {
    return res.status(400).json({ message: 'Serial number is required' });
  }

  // Attempt to delete the SIM
  SimModel.deleteOne({ serialNumber: serialNumber }, (err) => {
    if (err) {
      return res.status(500).json({ message: 'Error deleting SIM' });
    }

    res.status(200).json({ message: 'SIM deleted successfully' });
  });
};
// Update a SIM
export const updateSim = async (req, res) => {
  try {
    const { serialNumber } = req.params;
    const updatedData = req.body;

    const updatedSim = await Sim.findOneAndUpdate(
      { serialNumber },
      updatedData,
      { new: true }
    );

    if (!updatedSim) {
      return res.status(404).json({ message: 'SIM not found.' });
    }

    res.status(200).json({ message: 'SIM updated successfully.', updatedSim });
  } catch (error) {
    handleError(res, 500, 'Error updating SIM', error);
  }
};

// Get all employees associated with SIMs
export const getAllEmployees = async (req, res) => {
  try {
    const sims = await Sim.find({});

    const employees = sims
      .filter(sim => sim.employee)
      .map(sim => ({
        nom: sim.employee.nom,
        cin: sim.employee.cin,
        poste: sim.employee.poste,
        service: sim.employee.service,
        simSerialNumber: sim.serialNumber,
        phoneNumber: sim.phoneNumber,
        dateAttribution: sim.assignedAt
      }));

    res.status(200).json(employees);
  } catch (error) {
    handleError(res, 500, 'Error fetching employees', error);
  }
};
// Delete an employee by CIN
export const deleteEmployee = async (req, res) => {
  try {
    const { cin } = req.params;

    // Find the SIM associated with this employee
    const sim = await Sim.findOne({ "employee.cin": cin });

    if (!sim) {
      return res.status(404).json({ message: "Employee not found." });
    }

    // Remove the employee from the SIM record
    sim.employee = undefined;
    sim.phoneNumber = undefined; // Optionally remove phone number if needed
    sim.assignedAt = undefined;

    await sim.save();

    res.status(200).json({ message: "Employee deleted successfully.", sim });
  } catch (error) {
    handleError(res, 500, "Error deleting employee", error);
  }
};
export const updateEmployee = async (req, res) => {
  try {
    const { cin } = req.params;
    const { nom, poste, service, serialNumber, forfait, forfaitInternet } = req.body;

    // Find the SIM associated with this employee (based on CIN)
    const sim = await Sim.findOne({ "employee.cin": cin });

    if (!sim) {
      return res.status(404).json({ message: "Employee not found." });
    }

    // Update employee details in the SIM
    if (nom) sim.employee.nom = nom;
    if (poste) sim.employee.poste = poste;
    if (service) sim.employee.service = service;
    if (serialNumber) sim.serialNumber = serialNumber;
    if (forfait) sim.forfait = forfait;
    if (forfaitInternet) sim.forfaitInternet = forfaitInternet;

    // Save the updated SIM document
    await sim.save();

    res.status(200).json({ message: "Employee updated successfully.", sim });
  } catch (error) {
    handleError(res, 500, "Error updating employee", error);
  }
};