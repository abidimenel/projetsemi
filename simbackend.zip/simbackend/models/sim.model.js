import mongoose from 'mongoose';
import Counter from './counter.model.js';

const SimSchema = new mongoose.Schema({
  serialNumber: { type: String, required: true, unique: true },
  forfait: { type: String, required: false },
  forfaitInternet: { type: String, required: false},
  phoneNumber: { type: String, default: null },
  dateAjout: { type: Date, default: Date.now },
  assignedAt: { type: Date, default: null },
  employee: {
    employeeId: { type: Number, unique: true },
    nom: { type: String, required: false},
    cin: { type: String, required: false, unique: true },
    poste: { type: String, required: false },
    service: { type: String, required: false }
  }
});

SimSchema.pre('save', async function (next) {
  if (this.employee && !this.employee.employeeId) {
    try {
      const counter = await Counter.findByIdAndUpdate(
        { _id: 'employeeId' },
        { $inc: { seq_value: 1 } },
        { new: true, upsert: true }
      );
      this.employee.employeeId = counter.seq_value;
    } catch (error) {
      return next(error);
    }
  }
  next();
});

const Sim = mongoose.model('Sim', SimSchema);
export default Sim;
