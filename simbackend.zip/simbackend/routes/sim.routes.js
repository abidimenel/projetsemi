import express from 'express';
import {
  createSim,
  assignSimToEmployee,
  assignPhoneNumberToSim,
  getAllSims,
  deleteSim,
  updateSim,
  getAllEmployees,
 deleteEmployee ,
 updateEmployee
} from '../controllers/sim.controller.js';

const router = express.Router();

router.post('/create-sim', createSim);
router.post('/assign-sim', assignSimToEmployee);
router.post('/assign-phone-number', assignPhoneNumberToSim);
router.get('/getAllSims', getAllSims);
router.delete('/sims/:serialNumber', deleteSim);
router.put('/sims/:serialNumber', updateSim);
router.get('/getAllEmployees', getAllEmployees);
router.post('/assign-sim', assignSimToEmployee);
router.delete("/employees/:cin", deleteEmployee);
router.put("/employees/:cin", updateEmployee);

export default router;
