import { Component } from '@angular/core';
import { SimService } from '../sim.service';

@Component({
  selector: 'app-add-sim',
  templateUrl: './add-sim.component.html',
  styleUrls: ['./add-sim.component.css'],
})
export class AddSimComponent {
  barcodeValue: string | null = '';
  scannedChips: any[] = [];
  editingChip: any = null;
  successMessage: string = '';
  errorMessage: string = '';

  constructor(private simService: SimService) {}

  onBarcodeScanned(): void {
    if (this.barcodeValue && this.barcodeValue.trim()) {
      const barcode = this.barcodeValue.trim();

      // Vérifier si le code existe déjà
      const exists = this.scannedChips.some(chip => chip.barcode === barcode);
      if (!exists) {
        this.validateAndAddChip(barcode);
      } else {
        this.errorMessage = 'Cette puce est déjà scannée.';
        setTimeout(() => (this.errorMessage = ''), 2000);
      }

      this.barcodeValue = ''; // Réinitialiser le champ après scan
    }
  }

  validateAndAddChip(barcode: string): void {
    this.simService.createSim(barcode).subscribe(
      () => {
        this.scannedChips.unshift({ barcode, status: 'validé' }); // Ajout automatique en haut de la liste
        this.successMessage = `SIM ${barcode} validée et ajoutée.`;
        setTimeout(() => (this.successMessage = ''), 2000);
      },
      (error) => {
        console.error('Erreur lors de l’ajout de la SIM:', error);
        this.errorMessage = 'Erreur lors de la validation.';
        setTimeout(() => (this.errorMessage = ''), 2000);
      }
    );
  }


  addChipToBackend(barcode: string): void {
    const newSim = {
      serialNumber: barcode,
    };

    this.simService.createSim(barcode).subscribe(
      (data) => {
        this.scannedChips.push({
          barcode,
          status: 'non validé',
        });

        this.successMessage = `SIM ${barcode} added successfully.`;
        this.barcodeValue = '';
        this.errorMessage = '';
      },
      (error) => {
        console.error('Error adding SIM:', error);
        this.errorMessage = 'Error adding SIM.';
        this.successMessage = '';
      }
    );
  }

  updateChip(barcode: string): void {
    if (this.editingChip) {
      this.editingChip.barcode = barcode;
      this.editingChip = null;
    }
    this.barcodeValue = '';
  }

  editBarcode(chip: any): void {
    this.barcodeValue = chip.barcode;
    this.editingChip = chip;
  }

  deleteChip(chip: any): void {
    this.scannedChips = this.scannedChips.filter(c => c !== chip);
  }
}