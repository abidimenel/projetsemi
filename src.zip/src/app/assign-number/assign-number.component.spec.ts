import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignNumberComponent } from './assign-number.component';

describe('AssignNumberComponent', () => {
  let component: AssignNumberComponent;
  let fixture: ComponentFixture<AssignNumberComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AssignNumberComponent]
    });
    fixture = TestBed.createComponent(AssignNumberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
