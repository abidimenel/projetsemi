import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SimService } from '../sim.service';

@Component({
  selector: 'app-assign-number',
  templateUrl: './assign-number.component.html',
})
export class AssignNumberComponent {
  assignForm: FormGroup;

  constructor(private fb: FormBuilder, private simService: SimService) {
    this.assignForm = this.fb.group({
      serialNumber: ['', Validators.required],
      numTelephone: ['', Validators.required],
    });
  }

  onSubmit() {
    if (this.assignForm.valid) {
      const { serialNumber, numTelephone } = this.assignForm.value;
      this.simService.assignPhoneNumber(serialNumber, numTelephone).subscribe(
        (response) => {
          console.log('Number assigned successfully', response);
        },
        (error) => {
          console.error('Error assigning number', error);
        }
      );
    }
  }
}