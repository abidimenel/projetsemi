import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignSimComponent } from './assign-sim.component';

describe('AssignSimComponent', () => {
  let component: AssignSimComponent;
  let fixture: ComponentFixture<AssignSimComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AssignSimComponent]
    });
    fixture = TestBed.createComponent(AssignSimComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
