import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SimService } from '../sim.service';

@Component({
  selector: 'app-assign-sim',
  templateUrl: './assign-sim.component.html',
  styleUrls: ['./assign-sim.component.css'],
})
export class AssignSimComponent implements OnInit {
  assignForm: FormGroup;
  forfait: string = '30 DT';
  forfaitInternet: string = '15 Go';
  detailsVisible: boolean = false;

  constructor(
    private fb: FormBuilder,
    private simService: SimService
  ) {
    this.assignForm = this.fb.group({
      nom: ['', Validators.required],
      cin: ['', Validators.required],
      poste: ['', Validators.required],
      service: ['', Validators.required],
      serialNumber: ['', Validators.required],
      dateAttribution: [new Date().toISOString().split('T')[0], Validators.required],
    });
  }

  ngOnInit(): void {}

  onSubmit(): void {
    if (this.assignForm.valid) {
      const employeeData = this.assignForm.value;
      this.simService.assignSimToEmployee(employeeData.serialNumber, employeeData, this.forfait, this.forfaitInternet).subscribe(
        (response) => {
          console.log('SIM assigned successfully', response);
          this.detailsVisible = true;
        },
        (error) => {
          console.error('Error assigning SIM', error);
        }
      );
    }
  }

  onPosteChange(): void {
    const poste = this.assignForm.get('poste')?.value;
    switch (poste) {
      case 'technicien':
        this.forfait = '30 DT';
        this.forfaitInternet = '15 Go';
        break;
      case 'specialiste':
        this.forfait = '50 DT';
        this.forfaitInternet = '30 Go';
        break;
      case 'manager':
        this.forfait = '70 DT';
        this.forfaitInternet = '30 Go';
        break;
      case 'directeur':
        this.forfait = '100 DT';
        this.forfaitInternet = '30 Go';
        break;
      default:
        this.forfait = '30 DT';
        this.forfaitInternet = '15 Go';
    }
  }

  copyToClipboard(): void {
    const dataToCopy = `Nom: ${this.assignForm.value.nom}
CIN: ${this.assignForm.value.cin}
Poste: ${this.assignForm.value.poste}
Service: ${this.assignForm.value.service}
Forfait: ${this.forfait}
Forfait Internet: ${this.forfaitInternet}
Serial Number: ${this.assignForm.value.serialNumber}
Date d'attribution: ${this.assignForm.value.dateAttribution}`;

    navigator.clipboard.writeText(dataToCopy)
      .then(() => alert('Data copied to clipboard'))
      .catch((error) => console.error('Error copying to clipboard', error));
  }

  closeModal(): void {
    this.detailsVisible = false;
  }
}