import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import {jwtDecode} from 'jwt-decode';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private baseUrl = 'http://localhost:5000/api/auth';

  constructor(private http: HttpClient, private router: Router) {}
  
 isAuthentificated():boolean{
  return !!localStorage.getItem("usertoken")
 }
  signUp(email: string, password: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/signup`, { email, password });
  }

  login(email: string, password: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/login`, { email, password });
  }
  getLoggedInUser(): any | null {
    const token = localStorage.getItem('userToken');
    if (token) {
      try {
        return jwtDecode(token); // Décoder le token pour obtenir les informations de l'utilisateur
      } catch (error) {
        console.error('Erreur lors du décodage du token', error);
        return null;
      }
    }
    return null; // Aucun utilisateur connecté
  }

  // Après une connexion réussie, enregistre le token et redirige
  loginUser(email: string, password: string) {
    this.login(email, password).subscribe(
      (response) => {
        // Sauvegarde du token dans localStorage
        localStorage.setItem('userToken', response.token);
        // Redirection vers la page protégée (par exemple : dashboard)
        this.router.navigate(['/home_page']);
      },
      (error) => {
        console.error('Erreur de connexion', error);
      }
    );
  }
}
