import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomModalComponentComponent } from './custom-modal-component.component';

describe('CustomModalComponentComponent', () => {
  let component: CustomModalComponentComponent;
  let fixture: ComponentFixture<CustomModalComponentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CustomModalComponentComponent]
    });
    fixture = TestBed.createComponent(CustomModalComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
