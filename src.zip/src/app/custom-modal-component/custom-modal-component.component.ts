// custom-modal.component.ts
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-custom-modal',
  template: `
    <div *ngIf="isOpen" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div class="bg-white rounded-lg shadow-lg w-full max-w-md">
        <div class="flex justify-between items-center p-4 border-b">
          <h3 class="text-lg font-semibold">{{ title }}</h3>
          <button (click)="closeModal()" class="text-gray-500 hover:text-gray-700">
            &times;
          </button>
        </div>
        <div class="p-4">
          <ng-content></ng-content>
        </div>
        <div class="flex justify-end p-4 border-t">
          <button (click)="closeModal()" class="mr-2 px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
            Fermer
          </button>
          <button (click)="onSave()" class="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700">
            Enregistrer
          </button>
        </div>
      </div>
    </div>
  `,
})
export class CustomModalComponent {
  @Input() isOpen = false;
  @Input() title = 'Modale';
  @Output() close = new EventEmitter<void>();
  @Output() save = new EventEmitter<void>();

  closeModal(): void {
    this.close.emit();
  }

  onSave(): void {
    this.save.emit();
  }
}