import { Component, OnInit } from '@angular/core';
import { SimService } from '../sim.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css'],
})
export class EmployeeListComponent implements OnInit {
  employees: any[] = [];
  searchQuery: string = '';
  isFilterMenuOpen: boolean = false;
  isModalOpen = false; // Modal visibility state
  isEditModalOpen = false; // Edit modal state
  selectedEmployee: any = {}; // Selected employee to be edited

  constructor(private simService: SimService) {}

  ngOnInit(): void {
    this.loadEmployees();
  }

  loadEmployees(): void {
    this.simService.getAllEmployees().subscribe(
      (data: any) => {
        // Filter employees with a SIM and name
        this.employees = data.filter((employee: any) => 
          employee.simSerialNumber && employee.nom // Check for simSerialNumber and name
        );
      },
      (error) => {
        console.error('Error fetching employees', error);
      }
    );
  }

  toggleFilterMenu(): void {
    this.isFilterMenuOpen = !this.isFilterMenuOpen;
  }

  setFilterOption(option: string): void {
    console.log('Filter option:', option);
  }

  filterEmployees(): void {
    const query = this.searchQuery.toLowerCase();
    this.employees = this.employees.filter((employee) =>
      (employee.simSerialNumber && 
        (employee.nom || '').toLowerCase().includes(query) ||
        (employee.cin || '').toLowerCase().includes(query) ||
        (employee.poste || '').toLowerCase().includes(query) ||
        (employee.service || '').toLowerCase().includes(query))
    );
  }

  onSearchChange(): void {
    this.filterEmployees();
  }

  openEditModal(employee: any) {
    this.selectedEmployee = { ...employee }; // Clone the object to avoid direct modification
    this.isEditModalOpen = true;
  }

  closeEditModal() {
    this.isEditModalOpen = false;
  }

  updateEmployee() {
    if (!this.selectedEmployee.cin) {
      alert("Erreur: CIN de l'employé introuvable !");
      return;
    }

    this.simService.updateEmployee(this.selectedEmployee.cin, this.selectedEmployee).subscribe(
      (response) => {
        console.log("Employee updated successfully:", response);
        this.isEditModalOpen = false;
        this.loadEmployees(); // Refresh the list after update
      },
      (error) => {
        console.error("Error updating employee:", error);
      }
    );
  }

  deleteEmployee(employeeCin?: string) {
    if (!employeeCin) {
      console.error("Employee CIN is undefined");
      return;
    }

    this.simService.deleteEmployee(employeeCin).subscribe(
      () => {
        this.employees = this.employees.filter(emp => emp.cin !== employeeCin);
        console.log("Employee deleted successfully");
      },
      error => {
        console.error("Error deleting employee:", error);
      }
    );
  }
}
