import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

export interface Employee {
  id: string;
  nom: string;
  cin: string;
  poste: string;
  service: string;
  sim?: {
    serialNumber: string;
  };
  numTelephone?: string;
  simAssignedDate?: string;
}
@Injectable({
  providedIn: 'root',
})
export class EmployeeService {
  private apiUrl = 'http://localhost:5000/api/employees'; // API for employees
  private simApiUrl = 'http://localhost:5000/api/sims'; // API for SIMs

  constructor(private http: HttpClient) {}

  // Assign a phone number to a SIM
  assignNumber(serialNumber: string, phoneNumber: string): Observable<any> {
    return this.http.post(`${this.simApiUrl}/assign-number`, FormData).pipe(
      catchError((error) => {
        console.error('Error assigning number:', error);
        return throwError(() => new Error('Error assigning number.'));
      })
    );
  }

  // Assign a SIM to an employee
  assignSim(formData: Employee): Observable<any> {
    return this.http.post(`${this.simApiUrl}/assign-sim`, formData).pipe(
      catchError((error) => {
        console.error('Error assigning SIM:', error);
        return throwError(() => new Error('Error assigning SIM.'));
      })
    );
  }

  // Fetch all employees
  getAllEmployees(): Observable<any> {
    return this.http.get<any>(this.apiUrl);
  }

  // Update an employee
  updateEmployee(id: string, updatedData: Partial<Employee>): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, updatedData).pipe(
      catchError((error) => {
        console.error('Error updating employee:', error);
        return throwError(() => new Error('Error updating employee.'));
      })
    );
  }
}