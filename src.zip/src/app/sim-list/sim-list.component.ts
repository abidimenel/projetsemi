import { Component, OnInit } from '@angular/core';
import { SimService } from '../sim.service';

@Component({
  selector: 'app-sim-list',
  templateUrl: './sim-list.component.html',
  styleUrls: ['./sim-list.component.css'],
})
export class SimListComponent implements OnInit {
  sims: any[] = [];
  filteredSims: any[] = [];
  searchQuery: string = '';
  isEditing: boolean = false;
  selectedSim: any = null;

  constructor(private simService: SimService) {}

  ngOnInit(): void {
    this.loadSims();
  }

  // Load all SIMs
  loadSims(): void {
    this.simService.getAllSims().subscribe(
      (data: any) => {
        this.sims = Array.isArray(data) ? data : data.sims || [];
        this.filteredSims = [...this.sims];
      },
      (error) => {
        console.error('Error fetching SIMs', error);
      }
    );
  }

  // Filter SIMs based on search query
  filterSims(): void {
    if (!Array.isArray(this.sims)) {
      console.error('this.sims is not an array');
      this.filteredSims = [];
      return;
    }

    const query = this.searchQuery.toLowerCase();
    this.filteredSims = this.sims.filter(
      (sim) =>
        (sim.serialNumber || '').toLowerCase().includes(query) ||
        (sim.dateDajout ? sim.dateDajout.toString().toLowerCase().includes(query) : false) ||
        (sim.dateAttribution || '').toLowerCase().includes(query)
    );
  }

  // Handle search input change
  onSearchChange(): void {
    this.filterSims();
  }

  // Select a SIM for editing
  editSim(sim: any): void {
    this.selectedSim = { ...sim }; // Create a copy of the selected SIM
    this.isEditing = true;
  }

  // Save updated employee details
  saveEmployee(): void {
    if (!this.selectedSim || !this.selectedSim.employee) {
      alert('No employee selected for update.');
      return;
    }

    const updatedEmployee = {
      nom: this.selectedSim.employee.nom,
      poste: this.selectedSim.employee.poste,
      service: this.selectedSim.employee.service,
      serialNumber: this.selectedSim.serialNumber,
      forfait: this.selectedSim.forfait,
      forfaitInternet: this.selectedSim.forfaitInternet,
    };

    this.simService.updateEmployee(this.selectedSim.employee.cin, updatedEmployee).subscribe(
      (response: any) => {
        const updatedSim = response.sim; // Assuming your API returns updated SIM data

        // Find the index of the SIM in the list
        const index = this.sims.findIndex((sim) => sim.serialNumber === this.selectedSim.serialNumber);
        if (index !== -1) {
          // Replace the old SIM with the updated one
          this.sims[index] = { ...updatedSim };
        }

        // Update the filtered list as well
        this.filteredSims = [...this.sims];

        // Close the modal and reset the selectedSim
        this.isEditing = false;
        this.selectedSim = null;
        alert('Employee updated successfully.');
      },
      (error) => {
        console.error('Error updating employee', error);
        alert('Error updating employee.');
      }
    );
  }

  // Delete a SIM
  deleteSim(serialNumber: string): void {
    if (confirm('Are you sure you want to delete this SIM?')) {
      this.simService.deleteSim(serialNumber).subscribe(
        (response: any) => {
          console.log('SIM deleted successfully:', response);
          this.loadSims(); // Reload the SIM list after deletion
        },
        (error) => {
          console.error('Error deleting SIM:', error);
        }
      );
    }
  }

  // Cancel editing
  cancelEdit(): void {
    this.isEditing = false;
    this.selectedSim = null;
  }
}