import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class SimService {
 
  private simApiUrl = 'http://localhost:5000/api/sims'; // Base URL for SIM-related API requests
  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
  };

  constructor(private http: HttpClient) {}

  getAllSims(): Observable<any[]> {
    return this.http.get<any[]>(`${this.simApiUrl}/getAllSims`).pipe(
      catchError(error => {
        console.error('Error fetching SIMs', error);
        return of([]);
      })
    );
  }

  createSim(serialNumber: string): Observable<any> {
    return this.http.post<any>(`${this.simApiUrl}/create-sim`, { serialNumber }, this.httpOptions).pipe(
      catchError(error => {
        console.error('Error creating SIM', error);
        return of({ error: 'Failed to create SIM', details: error.message });
      })
    );
  }
  deleteSim(serialNumber: string): Observable<any> {
    return this.http.delete(`${this.simApiUrl}?serialNumber=${serialNumber}`);
  }
  
  assignPhoneNumber(serialNumber: string, phoneNumber: string): Observable<any> {
    return this.http.post<any>(`${this.simApiUrl}/assign-phone-number`, { serialNumber, phoneNumber }, this.httpOptions).pipe(
      catchError(error => {
        console.error('Error assigning phone number', error);
        return of({ error: 'Failed to assign phone number', details: error.message });
      })
    );
  }

  assignSimToEmployee(serialNumber: string, employeeData: any, forfait: string, forfaitInternet: string): Observable<any> {
    return this.http.post<any>(`${this.simApiUrl}/assign-sim`, { serialNumber, ...employeeData, forfait, forfaitInternet }, this.httpOptions).pipe(
      catchError(error => {
        console.error('Error assigning SIM to employee', error);
        return of({ error: 'Failed to assign SIM to employee', details: error.message });
      })
    );
  }

  getAllEmployees(): Observable<any[]> {
    return this.http.get<any[]>(`${this.simApiUrl}/getAllEmployees`).pipe(
      catchError(error => {
        console.error('Error fetching employees', error);
        return of([]);
      })
    );
  }
  updateSim(serialNumber: string, simData: any): Observable<any> {
    return this.http.put(`${this.simApiUrl}/${serialNumber}`, simData).pipe(
      catchError(error => {
        console.error('Error updating SIM', error);
        return of({ error: 'Failed to update SIM', details: error.message });
      })
    );
  }
 // Dans SimService
 deleteEmployee(employeeCin: string): Observable<any> {
  return this.http.delete(`${this.simApiUrl}/employees/${employeeCin}`);
}


updateEmployee(cin: string, employeeData: any): Observable<any> {
  return this.http.put(`${this.simApiUrl}/employees/${cin}`, employeeData);
}
}